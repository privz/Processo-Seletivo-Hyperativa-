Desafio 2 Hyperativa

Orientações:

Todas as imagens utilizadas foram disponibilizadas no primeiro desafio.
