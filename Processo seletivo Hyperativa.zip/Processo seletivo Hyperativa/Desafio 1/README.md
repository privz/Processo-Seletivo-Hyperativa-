Desafio Hyperativa 1
==================

## Orientações

1. Instalar a Fonte OpenSans no Google fonts: https://fonts.google.com/specimen/Open+Sans?query=Open+san. Para instalar ela, precisa apenas usar o <style>@import url('https://fonts.googleapis.com/css2?family=Open+Sans&display=swap');</style> dentro do HEAD.

2. Todas imagens utilizadas são as mesmas que foram disponibilizadas.

3. E é isso, obrigado pela oportunidade e espero que vocês gostem!